# `🧿 𝚃𝚑𝚎 𝙼𝚢𝚜𝚝𝚒𝚌 - 𝙱𝚘𝚝 🔮`

### `—◉ 👑 DUDAS SOBRE EL BOT?, CONTACTANOS 👑`
<a href="http://wa.me/5219992095479" target="blank"><img src="https://img.shields.io/badge/BRUNO_SOBRINO_CREADOR-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="http://wa.me/34642467703" target="blank"><img src="https://img.shields.io/badge/UNPTOADHIH15_COLAB.1-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="http://wa.me/50499698072" target="blank"><img src="https://img.shields.io/badge/ALBERTO_ACOSTA_COLAB.2-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="http://wa.me/595986460945" target="blank"><img src="https://img.shields.io/badge/AIDEN_NOTLOGIC_COLAB.3-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="http://wa.me/51940617554" target="blank"><img src="https://img.shields.io/badge/GATITO_COLAB.4-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

<a href="https://chat.whatsapp.com/G18HUF7pntwFgkVoMbhvs3" target="blank"><img src="https://img.shields.io/badge/GRUPO_DE_SOPORTE-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</a>
> LOS NUMEROS NO SON BOTS Y EN EL GRUPO NO SE PERMITEN NUMEROS-BOTS

### `—◉ 💰 DONAR 💰`
- AGRADECE CON UNA DONACION VOLUNTARIA [Aqui](https://www.paypal.me/TheShadowBrokers133)

### `—◉ 🖍 LETRA DEL BOT 🖍`
- PAGINA USADA PARA LA LETRA [Aqui](https://smiley.cool/es/weirdmaker.php)

### `—◉ ✨ ACTIVAR EN HEROKU ✨`
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/BrunoSobrino/TheMystic-Bot-MD)
```bash
AÑADE AL APARTADO DE BUILPACK LO SIGUIENTE, SI YA APARCEN SOLO IGNORA ESTA PARTE:
> heroku/nodejs
> https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git
> https://github.com/clhuang/heroku-buildpack-webp-binaries.git
> https://github.com/DuckyTeam/heroku-buildpack-imagemagick.git
ADVERTENCIA: HEROKU ESTA SUSPENDIENDO CUENTAS POR SOLO USAR EL BOT, POR AHORA NO ES RECOMENDABLE USAR EL BOT EN HEROKU!
```

### `—◉ ⚙️ AJUSTES ⚙️`
- CLONAR EL REPOSITORIO [Aqui](https://github.com/BrunoSobrino/TheMystic-Bot-MD/fork)
- CAMBIAR NÚMERO DEL OWNER [Aqui](https://github.com/BrunoSobrino/TheMystic-Bot-MD/blob/master/config.js)

### `—◉ 👾 ACTIVAR EN TERMUX 👾`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd
> termux-setup-storage
> apt update 
> pkg upgrade 
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> pkg install yarn
> git clone https://github.com/BrunoSobrino/TheMystic-Bot-MD
> cd TheMystic-Bot-MD
> yarn install 
> npm update
> npm start
```

### `—◉ ✔️ ACTIVAR EN CASO DE DETENERSE ✔️`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd TheMystic-Bot-MD
> npm start
```

### `—◉ 👽 OBTENER OTRO CODIGO QR 👽`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd TheMystic-Bot-MD
> rm -rf session.data.json
> npm start
```

### `—◉ 🔥 ACTIVAR EN BOXMINEHOST 🔥`
<a href="https://boxmineworld.com"><img src="https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/Pre%20Bot%20Publi.png" width="450" height="240" alt="JPG"/></a>
<p>> Pagina Oficial:
<a href="https://boxmineworld.com">https://boxmineworld.com</a>
<p>> Dashboard:
<a href="https://dash.boxmineworld.com/home">https://dash.boxmineworld.com/home</a>
<p>> Panel:
<a href="https://panel.boxmineworld.com">https://panel.boxmineworld.com</a>
<p>> Tutorial:
<a href="https://youtu.be/eC9TfKICpcY">https://youtu.be/eC9TfKICpcY</a>
<p>> Dudas UNICAMENTE SOBRE EL HOST:
<a href="https://discord.gg/84qsr4v">https://discord.gg/84qsr4v</a> (Preguntar por Vicemi)
</p>
  
### `—◉ 💥 ACTIVAR EN ACIDICNODES 💥`
<a href="https://billing.acidicnodes.ml/register?ref=ADII104p"><img src="https://billing.acidicnodes.ml/storage/icon.png" width="100" height="100" alt="acidicnodes"/></a>

### `—◉ 📝 NOTAS 📝`
```bash
- ES POSIBLE QUE EL BOT TENGA ALGUNAS FALLAS, SE IRAN SOLUCIONANDO CONFORME SE VAYAN DETECTANDO
- SI VAS A EDITAR POR COMPLETO DEJA LOS CREDITOS DEL BOT 
- EL BOT ES COMPARTIBLE CON WHATSAPP NORMAL O BUSINESS
- ATENTO A LAS ACTUALIZACIONES QUE SE HAGAN EN ESTE REPOSITORIO
- EL ADD Y EL KICK PUEDEN OCASIONAR QUE EL NUMERO SE VAYA A SOPORTE POR ELLO SE ACTIVA CON #enable restrict 
- THE SHADOW BROKERS - TEAM NO SE HACE RESPONSABLE DEL USO, NUMEROS, PRIVACIDAD Y CONTENIDO MANDADO, USADO O GESTIONADO POR USTEDES O EL BOT
```

## `COLABORADORES DEL BOT` 
<a href="https://github.com/unptoadrih15"><img src="https://github.com/unptoadrih15.png" width="200" height="200" alt="unptoadrih15"/></a>
<a href="https://github.com/ALBERTO9883"><img src="https://github.com/ALBERTO9883.png" width="200" height="200" alt="ALBERTO9883"/></a>
<a href="https://github.com/ferhacks"><img src="https://github.com/ferhacks.png" width="200" height="200" alt="ferhacks"/></a>
<a href="https://github.com/g4tito"><img src="https://github.com/g4tito.png" width="200" height="200" alt="g4tito"/></a>

## `EDITOR Y PORPIETARIO DEL BOT` 
<a href="https://github.com/BrunoSobrino"><img src="https://github.com/BrunoSobrino.png" width="300" height="300" alt="BrunoSobrino"/></a>

`TheMystic-Bot-MD _ By Bruno Sobrino`
